import mod1
#from mod2.mod2 import * 
import mod2.mod2
