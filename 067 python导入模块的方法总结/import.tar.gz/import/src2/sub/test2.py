import sys 
sys.path.append("..") 
import mod1 
#or#import mod2.mod2
from mod2.mod2 import * 

