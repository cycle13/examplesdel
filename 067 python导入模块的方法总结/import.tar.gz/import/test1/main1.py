import sys
sys.path.append("./module/a_file") 
import a
