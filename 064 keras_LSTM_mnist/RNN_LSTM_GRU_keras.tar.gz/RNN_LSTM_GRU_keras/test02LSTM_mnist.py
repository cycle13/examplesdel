# -*- coding: utf-8 -*-
'''
RNN_LSTM_GRU_keras test02
LSTM_mnist
env:Linux ubuntu 4.4.0-31-generic x86_64 GNU;python 2.7;tensorflow1.10.1;Keras2.2.4
'''
import keras
from keras.layers import LSTM
from keras.layers import Dense, Activation
from keras.datasets import mnist
from keras.models import Sequential,Model
from keras.optimizers import Adam
import os
from keras.models import load_model

model_dir = 'model'
model_file = os.path.join(model_dir, 'model_lstmmnist.h5')
 
learning_rate = 0.001
epoch = 2#20
batch_size = 128
 
n_input = 28
n_step = 28
n_hidden = 128
n_classes = 10
#1. 数据预处理。
(x_train, y_train), (x_test, y_test) = mnist.load_data()
x_train = x_train.reshape(-1, n_step, n_input)
x_test = x_test.reshape(-1, n_step, n_input)
x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255
 
y_train = keras.utils.to_categorical(y_train, n_classes)
y_test = keras.utils.to_categorical(y_test, n_classes)
print('x_train.shape:',x_train.shape)
print('y_train.shape:',y_train.shape)
print('x_test.shape:',x_test.shape)
print('y_test.shape:',y_test.shape)
'''
#define model network
model = Sequential()
model.add(LSTM(n_hidden,
               batch_input_shape=(None, n_step, n_input),
               unroll=True,name='LSTM_layer'))
model.add(Dense(n_classes,name='Dense_layer'))
model.add(Activation('softmax',name='activation_layer'))
model.summary()
adam = Adam(lr=learning_rate)
model.compile(optimizer=adam,
              loss='categorical_crossentropy',
              metrics=['accuracy'])
#train and save model
model.fit(x_train, y_train,
          batch_size=batch_size,
          epochs=epoch,
          verbose=2,
          validation_data=(x_test, y_test))
print('save the trained model')
if not os.path.exists(model_dir):
	os.mkdir(model_dir)
model.save(model_file)#elesun
'''
#load model and test
print('load the trained model')
if not os.path.isfile(model_file):
    print(model_file+" not exist!")
    exit(0)
model = load_model(model_file)
model.summary()
print 'model.input=',model.input
print 'model.input.name=',model.input.name
print 'model.input.shape=',model.input.shape
print 'model.output=',model.output
print 'model.output.name=',model.output.name
print 'model.output.shape=',model.output.shape 
#get LSTM_layer output
LSTM_layer_model = Model(inputs=model.input,outputs=model.get_layer('LSTM_layer').output)
LSTM_layer_output = LSTM_layer_model.predict(x_test)
print 'LSTM_layer_output.shape=',LSTM_layer_output.shape
print 'LSTM_layer_output featuresmap=\n',LSTM_layer_output
#get LSTM_layer weights too many params
#weight_LSTM,bias_LSTM = model.get_layer('LSTM_layer').get_weights()
#print 'weight_LSTM_layer.shape=',weight_LSTM.shape
#print 'bias_LSTM_layer.shape=',bias_LSTM.shape
#get Dense_layer output
LSTM_layer_model = Model(inputs=model.input,outputs=model.get_layer('Dense_layer').output)
LSTM_layer_output = LSTM_layer_model.predict(x_test)
print 'Dense_layer_output.shape=',LSTM_layer_output.shape
print 'Dense_layer_output featuresmap=\n',LSTM_layer_output
#get Dense_layer weights
weight_Dense,bias_Dense = model.get_layer('Dense_layer').get_weights()
print 'weight_Dense_layer.shape=',weight_Dense.shape
print 'bias_Dense_layer.shape=',bias_Dense.shape
#get activation_layer output
LSTM_layer_model = Model(inputs=model.input,outputs=model.get_layer('activation_layer').output)
LSTM_layer_output = LSTM_layer_model.predict(x_test)
print 'activation_layer_output.shape=',LSTM_layer_output.shape
print 'activation_layer_output featuresmap=\n',LSTM_layer_output
#get activation_layer weights no param
#weight_activation,bias_activation = model.get_layer('activation_layer').get_weights()
#print 'weight_activation_layer.shape=',weight_activation.shape
#print 'bias_activation_layer.shape=',bias_activation.shape

scores = model.evaluate(x_test, y_test, verbose=0)
print('LSTM mnist test loss:', scores[0])
print('LSTM mnist test accuracy:', scores[1])

