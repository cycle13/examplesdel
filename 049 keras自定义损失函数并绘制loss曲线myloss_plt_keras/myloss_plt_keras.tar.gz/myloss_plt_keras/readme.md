sun@ubuntu:~/sun$ nohup python mnist_cnn.py >out.log &
