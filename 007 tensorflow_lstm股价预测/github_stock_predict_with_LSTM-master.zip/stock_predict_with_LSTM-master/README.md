## Predict stock with LSTM

This code refers to the blog post:[Tensorflow Instance](https://blog.csdn.net/mylove0414/article/details/55805974)

This project includes training and predicting processes with LSTM.

And you can run it on Windows or Linux.What you only need to do is to change the save path on different platform.
